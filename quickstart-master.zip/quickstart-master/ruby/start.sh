#!/usr/bin/env bash

ruby app.rb