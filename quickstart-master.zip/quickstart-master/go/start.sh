#!/usr/bin/env bash

go run server.go