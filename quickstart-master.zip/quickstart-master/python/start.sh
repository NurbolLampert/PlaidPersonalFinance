#!/usr/bin/env bash

python server.py || python3 server.py